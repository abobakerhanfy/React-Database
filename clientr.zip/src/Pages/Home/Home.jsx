
import React from 'react'
import Footer from '../../Components/Footer'
import SlideHome from '../../Components/SliderHome/SliderHome';
import Something from '../../Components/Something'
import Tracks from './../../Components/Tracks';

export default function Home() {
    return (
        <div>
            <SlideHome/>
         <Something/>
         <Tracks/>
         <Footer/>  
        </div>
    )
}
