import React from 'react'
import TopNavbar from './TopNavbar/TopNavbar';
import Navbar from './Navbar/Navbar';

export default function Header() {
  return (
    <div>
      <TopNavbar/>
      <Navbar/>
    </div>
  )
}
