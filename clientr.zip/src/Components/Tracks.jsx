import React from 'react'
import './Tracks.css'
import hirewebsitedesignv2 from '../Public/imgHome/hirewebsitedesignv2.svg'
import hiretranslation from '../Public/imgHome/hiretranslation.svg'
import hirepython from '../Public/imgHome/hirepython.svg'
import hireexcel from '../Public/imgHome/hireexcel.svg'
import hirephotoshopv2 from '../Public/imgHome/hirephotoshopv2.svg'
import hire3dmodellingv2 from '../Public/imgHome/hire3dmodellingv2.svg'
import hirewordpress from '../Public/imgHome/hirewordpress.svg'
import hireresearch from '../Public/imgHome/hirewebsearch.svg'
import hireghostwritingv2 from '../Public/imgHome/hirewebsitedesignv2.svg'
import hiretechnicalwritingv2 from '../Public/imgHome/hiretechnicalwritingv2.svg'
import  hireandroidv2 from '../Public/imgHome/hireandroidv2.svg'
import  hireresearchwriting from '../Public/imgHome/hireresearchwriting.svg'
import  hirecopywritingv2 from '../Public/imgHome/hirecopywritingv2.svg'
import  hireblogging from '../Public/imgHome/hireblogging.svg'
import  hireiphoneappsv2 from '../Public/imgHome/hireiphoneappsv2.svg'
import  hirearticlewritingv2 from '../Public/imgHome/hirearticlewritingv2.svg'
import  hireaccountingv2 from '../Public/imgHome/hireaccountingv2.svg'
import  hireinternetmarketingv2 from '../Public/imgHome/hireinternetmarketingv2.svg'
import  hiresoftwarearchitecture from '../Public/imgHome/hiresoftwarearchitecture.svg'
import  hirewebscraping from '../Public/imgHome/hirewebscraping.svg'
import  hirelegalv2 from '../Public/imgHome/hirelegalv2.svg'
import  hiremysql from '../Public/imgHome/hiremysql.svg'
import  hireecommerce from '../Public/imgHome/hireecommerce.svg'
import  hiregraphicdesignv2 from '../Public/imgHome/hiregraphicdesignv2.svg'
import  hirehtml from '../Public/imgHome/hirehtml.svg'
import  hirelinuxv2 from '../Public/imgHome/hirelinuxv2.svg'
import  hirebannerdesignv2 from '../Public/imgHome/hirebannerdesignv2.svg'
import  hiredataentryv2 from '../Public/imgHome/hiredataentryv2.svg'
import  hirelogodesignv2 from '../Public/imgHome/hirelogodesignv2.svg'
import  hirecss from '../Public/imgHome/hirecss.svg'
import  hiremanufacturingv2 from '../Public/imgHome/hiremanufacturingv2.svg'
import  hireillustration from '../Public/imgHome/hireillustration.svg'
import  hirelinkbuilding from '../Public/imgHome/hirelinkbuilding.svg'
import  hirepr from '../Public/imgHome/hirepr.svg'
import  hirehtml5 from '../Public/imgHome/hirehtml5.svg'
import  hireawsv2 from '../Public/imgHome/hireawsv2.svg'
import  hiresoftwaredevv2 from '../Public/imgHome/hiresoftwaredevv2.svg'
import  hirecplusplus from '../Public/imgHome/hirecplusplus.svg'
import  hirelogisticsv2 from '../Public/imgHome/hirelogisticsv2.svg'
import  hirejavascript from '../Public/imgHome/hirejavascript.svg'
import  hirecontentwriting from '../Public/imgHome/hirecontentwriting.svg'
import  hirephpv2 from '../Public/imgHome/hirephpv2.svg'
import  hirecsharp from '../Public/imgHome/hirecsharp.svg'
import  hireproofreading from '../Public/imgHome/hireproofreading.svg'
import  hiremarketing from '../Public/imgHome/hiremarketing.svg'
import  seeall from '../Public/imgHome/seeall.svg'
import hirefinancev2 from '../Public/imgHome/hirefinance-v2.svg'


export default function Tracks() {
    return (
        <div class="container">
            <div class="row">
            <div class="Tsectiontwo col-md-12 mb-5 mt-5"><b>Get work done in over 1800 different categories</b></div>
           <div class="col-md-12">
               <div class="row">
               <div class="col d-flex">
                   <img class="svIcon" src={hirewebsitedesignv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Website Design</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hiretranslation}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Translation</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirepython}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Python</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hireexcel}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Excel</a>
               </div>   
               <div class="col d-flex"><img class="svIcon" src={hirephotoshopv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Photoshop</a>
               </div>   
               </div>
           </div>
           {/* <!-- _________________________________________2_____________________________________ --> */}
           <div class="col-md-12 mt-4">
               <div class="row">
               <div class="col d-flex">
                   <img class="svIcon" src={hire3dmodellingv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Mobile Apps</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hireresearch}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Research</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirewordpress}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Wordpress</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hireghostwritingv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Ghostwriting</a>
               </div>   
               <div class="col d-flex"><img class="svIcon" src={hiretechnicalwritingv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Technical Writing</a>
               </div>   
               </div>
           </div>
           {/* <!-- ____________________________________________3______________________________________ --> */}
           <div class="col-md-12 mt-4">
               <div class="row">
               <div class="col d-flex">
                   <img class="svIcon" src={hireandroidv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Android Apps</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hireresearchwriting}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Research Writing</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hireresearch}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Web Search</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirecopywritingv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Copywriting</a>
               </div>   
               <div class="col d-flex"><img class="svIcon" src={hireblogging}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Blogging</a>
               </div>   
               </div>
           </div>
           {/* <!-- ______________________________________________4__________________________________________ --> */}
           <div class="col-md-12 mt-4">
               <div class="row">
               <div class="col d-flex">
                   <img class="svIcon" src={hireiphoneappsv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">iPhone Apps</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirearticlewritingv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Article Writing</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirefinancev2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Finance</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hireaccountingv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Accounting</a>
               </div>   
               <div class="col d-flex"><img class="svIcon" src={hireinternetmarketingv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Internet Marketing</a>
               </div>   
               </div>
           </div>
            {/* _____________________________________________5__________________________________________/  */}
           <div class="col-md-12 mt-4">
               <div class="row">
               <div class="col d-flex">
                   <img class="svIcon" src={hiresoftwarearchitecture}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Software Architecture</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirewebscraping}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Web Scraping</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirelegalv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Legal</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hiremysql}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">MySQL</a>
               </div>   
               <div class="col d-flex"><img class="svIcon" src={hireecommerce}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">eCommerce</a>
               </div>   
               </div>
           </div>
           {/* <!-- _____________________________________________6_________________________________________ --> */}
           <div class="col-md-12 mt-4">
               <div class="row">
               <div class="col d-flex">
                   <img class="svIcon" src={hiregraphicdesignv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Graphic Design</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirehtml}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">HTML</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirelinuxv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Linux</a>
               </div>   
               <div class="col d-flex">
                   <img class="svIcon" src={hirebannerdesignv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Banner Design</a>
               </div>   
               <div class="col d-flex"><img class="svIcon" src={hiredataentryv2}/>
                   <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Data Entry</a>
               </div>   
               </div>
           </div>
           {/* <!-- _____________________________________________7_____________________________________ --> */}
           <div class="col-md-12 mt-4">
               <div class="row">
                   <div class="col d-flex">
                       <img class="svIcon" src={hirelogodesignv2}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Logo Design</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hirecss}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">CSS</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hiremanufacturingv2}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Manufacturing</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hireillustration}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Illustration</a>
                   </div>   
                   <div class="col d-flex"><img class="svIcon" src={hirelinkbuilding}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Link Building</a>
                   </div>   
                   </div>
               </div>
               {/* <!-- _____________________________________________8_______________________________________ --> */}
               <div class="col-md-12 mt-4">
                   <div class="row">
                   <div class="col d-flex">
                       <img class="svIcon" src={hirepr}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Public Relations</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hirehtml5}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">HTML 5</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hireawsv2}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Amazon Web Services</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hiresoftwaredevv2}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Software Development</a>
                   </div>   
                   <div class="col d-flex"><img class="svIcon" src={hirecplusplus}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">C++ Programming</a>
                   </div>   
                   </div>
               </div>
               {/* <!-- ______________________________________________9_______________________________________ --> */}
               <div class="col-md-12 mt-4">
                   <div class="row">
                   <div class="col d-flex">
                       <img class="svIcon" src={hirelogisticsv2}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Logistics</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hirejavascript}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Javascript</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hirecontentwriting}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Content Writing</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hirephpv2}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">PHP</a>
                   </div>   
                   <div class="col d-flex"><img class="svIcon" src={hirecsharp}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">C# Programming</a>
                   </div>   
                   </div>
               </div>
               {/* <!-- ____________________________________________10_________________________________________ --> */}
               <div class="col-md-12 mt-4">
                   <div class="row">
                   <div class="col d-flex">
                       <img class="svIcon" src={hireproofreading}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Proofreading</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hiredataentryv2}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Data Processing</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hiremarketing}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">Marketing</a>
                   </div>   
                   <div class="col d-flex">
                       <img class="svIcon" src={hire3dmodellingv2}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">3D Modelling</a>
                   </div>   
                   <div class="col d-flex"><img class="svIcon" src={seeall}/>
                       <a  href="#" class="titleIcon ms-2 text-decoration-none text-dark">See All</a>
                   </div>   
                   </div>
               </div>
            </div>
        </div>
    )
}
