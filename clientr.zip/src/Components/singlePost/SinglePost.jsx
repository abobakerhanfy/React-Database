import axios from "axios";
import { useState } from "react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useHistory, useLocation } from "react-router-dom/cjs/react-router-dom.min";
import "./singlePost.css";

export default function SinglePost() {
  // const PF = "http://localhost:5000/images/"
  const PF = "http://localhost:6000/images/";

  const location = useLocation();
  const history = useHistory()
  const path =   location.pathname.split('/')[2];
  console.log(history)
const [post, setPost] = useState({})
  useEffect(() => {
    const getPost = async () =>{
      const res = await axios.get('/post/'+ path);
      setPost(res.data);
      console.log(res.data);

    }
    getPost();
  }, [path]);
  return (
    <div className="singlePost">
      <div className="singlePostWrapper">
        {post.photo && (
        <img
          className="singlePostImg"
          src={PF + post.photo}
          alt=""
        />
        )}
        <h1 className="singlePostTitle">
{post.title}          <div className="singlePostEdit">
            <i className="singlePostIcon far fa-edit"></i>
            <i className="singlePostIcon far fa-trash-alt"></i>
          </div>
        </h1>
        <div className="singlePostInfo">
          <span>
            Author:
            <b className="singlePostAuthor">
            <Link to={`/?user=${post.username}`} className="link">

              {post.username}

            </Link>

            </b>
          </span>
          <span>{new Date(post.createdAt).toDateString()}</span>
        </div>
        <p className="singlePostDesc">
     {post.desc}
          </p>
      </div>
    </div>
  );
}
