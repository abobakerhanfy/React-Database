import React, { useContext } from 'react'
import Logo from '../../Public/Image/Freelancerlogo.svg';
import { Link} from 'react-router-dom'
import "./TopNavbar.css"
import { ChatBubbleOutlineOutlined, ExploreOutlined, LocalMallOutlined, NotificationsOutlined, PeopleOutlined } from '@material-ui/icons';
import { Context } from '../../context/Context';
export default function TopNavbar() {
  const { user, dispatch } =useContext(Context);
  const LogoutHandle = () =>{
    dispatch({type: "LOGOUT"})
    window.location.replace('/');

  }
  console.log();
      return (
        <div>
            <nav class="bg-white navbar navbar-expand-lg navbar-light he-max">
  <div class="container-fluid p-0">
  {user ? (  <Link class="navbar-brand" to="/Dashbaord">
<img src={Logo} alt="" class="w-50" />
</Link>
  ) :  (  <Link class="navbar-brand" to="/">
<img src={Logo} alt="" class="w-50" />
</Link>
  )}
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0  ">
        <li class=" link nav-item">
          <Link className='link ms-1'>  {user ? "" :  "How It Works"}</Link>
        </li>
        <li class="nav-item">
          <Link className='link ms-4'> {user ? "" :  "Browse Jobs"} </Link>
        </li>
        <li class="nav-item">
        {user &&
          <Link className='link ms-4'>      <ExploreOutlined></ExploreOutlined> Browse </Link>
        }</li>
        <li class="nav-item">
        {user &&
          <Link className='link ms-4'>  <LocalMallOutlined></LocalMallOutlined>  Manage  </Link>
}</li>
        <li class="nav-item">
        {user &&
          <Link className='link ms-4'> <PeopleOutlined></PeopleOutlined> Browse Jobs </Link>
             }     </li>
      </ul>
    {user ?   <div class="d-flex justify-content-center align-items-center">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 justify-content-center align-items-center">
        <NotificationsOutlined></NotificationsOutlined>
        <ChatBubbleOutlineOutlined></ChatBubbleOutlineOutlined>
        <span className="px-1"></span>
        <button type="button" class="btn master-bk"> Post a Project </button>
        <div class="dropdown ">
  <button class="btn dropdown-toggle d-flex" type="button" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="false">
  <img
        className="headerImg"
        src="https://images.pexels.com/photos/1167355/pexels-photo-1167355.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"
        alt=""
      />
      <div className="d-flex flex-column">
      <small>{user.userName}</small>
      <small>0.00 USD</small>
      </div>
  </button>
  <ul class="dropdown-menu " aria-labelledby="dropdownMenu2">
    <li><button class="dropdown-item" type="button">Action</button></li>
    <li><button class="dropdown-item" type="button">Another action</button></li>
    <Link  className="link ms-3" onClick={LogoutHandle}>Logout</Link>
  </ul>
</div>
        </ul>
        </div>
        :
      <div class="d-flex justify-content-center align-items-center">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
         <Link  class="link" to="/Login"> Log In</Link>
        </li>
        <li class="nav-item ms-4">
          <Link class="link" to="/SignUp"> Sign Up</Link>
        </li>

      
      </ul>
        <button class="btn postproject m-1" >Post Project</button>
      </div>
}
    </div>
  </div>
</nav>
        </div>
    )
}
