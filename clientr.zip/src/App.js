
import './App.css';
import React, { useContext } from 'react'
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom'
// import './../Components/Header/Header.css'
import SignUp from './Components/SignUp/Signup';
// import NoFoundPage from './Pages/NoFoundPage/NoFoundPage';
import Home from './Pages/Home/Home';
import Login from './Pages/Login/Login';
import { Context } from './context/Context';
import Dashbaord from './Pages/Dashbaord/Dashbaord';
import Header from './Components/Header';
import Single from './Pages/single/Single';
import Feedback from './Pages/Feedback/Feedback';
function App() {
  const {user} = useContext(Context);
  return (
    <div className="App">
<Router>
<Header/>
  <Switch>
  <Route path="/"  exact  component={Home}/>
  <Route path="/Login"  exact component={Login}/>

    {user ? <Dashbaord/> : <Home/>}
  <Route path="/SignUp"   exact component={SignUp}/>
  <Route path="/Dashbaord"   exact component={Dashbaord}/>
  {
    user &&
  <Route path="/Feedback" exact component={Feedback}/>
  }
  <Router path="/project/:projectId">
<Single/>
  </Router>
  {/* <Route path="**"  exact component={NoFoundPage}/> */}
  </Switch>
</Router>
 
        </div>

  );
}

export default App;
