
import React, { useContext } from 'react'
import { BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import TopNavbar from './Components/TopNavbarAfterLgoin/TopNavbarAfterLgoin';
import NavbarAfterLogin from './Components/NavbarAfrerLogin/NavbarAfterLogin';
import { Context } from './context/Context';
import Dashbaord from './Pages/Dashbaord/Dashbaord';
function App() {
  const {user} = useContext(Context);
  return (
    <div className="App">

<Router>
<Switch>
    <TopNavbar/>
    <NavbarAfterLogin/>
    <Route path="/Dashboard"> {user && <Dashbaord/>}</Route>
</Switch>
</Router>
        </div>

  );
}

export default App;
